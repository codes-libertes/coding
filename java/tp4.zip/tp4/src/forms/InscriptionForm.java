package forms;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import beans.NewsBean;
import beans.PersonneBean;
import daos.NewsDao;
import daos.NewsDaoImpl;
import daos.PersonneDao;
import daos.PersonneDaoImpl;

public class InscriptionForm {

	private PersonneDao personneDao;
	private NewsDao newsDao;
	
	private StringBuilder resultat;
	
	public InscriptionForm(){
		personneDao = new PersonneDaoImpl();
		newsDao = new NewsDaoImpl();
		resultat = new StringBuilder();
	}
	
	private boolean validateLogin(String login){
		if ( login != null && login.length() < 4 ) {
			resultat.append("Le login doit contenir au moins 4 caractères." );
			return false;
	     }
		   
		return true;
	} 
	
	private boolean validatePassword(String password){
		if ( password != null && password.length() < 6 ) {
			resultat.append( "Le mot de passe doit contenir au moins 6 caractères." );    
			return false;
        }
		if(password.equals("' OR 1=1#")){
			resultat.append( "Le mot de passe est pas correct." );    
			return false;
		}
		return true;
	}
	
	public void inscrireComment(HttpServletRequest request){
		String comment = request.getParameter("comment");
		NewsBean news = new NewsBean();
		news.setComment(comment);
		
		newsDao.insererNews(news);
	}
	
	public List<String>  lireComments(){
		List<String> comments = new ArrayList<String>();
		comments = newsDao.lireNews();
		
		return comments;
	}
	
	public String inscrireForm(HttpServletRequest request){
		String login = request.getParameter("lgn");
		String password = request.getParameter("pwd");
		
		if((!validateLogin(login)) || (!validatePassword(password))){
			resultat.append("Echec de l'inscription");
			return this.resultat.toString();
		}
		
		String nom = login.split("\\.")[0];
		String prenom = login.split("\\.")[1];
		
		PersonneBean personne = new PersonneBean();
		personne.setLogin(login);
		personne.setPassword(password);
		personne.setNom(nom);
		personne.setPrenom(prenom);
		
		
		if( !(personneDao.verifierExistanceSelonLogin(personne))){
			resultat.append("Echec de l'inscription: Sans authentification ~~");
			return this.resultat.toString();
		}
		if( !(personneDao.verifierExistanceSelonPassword(personne))){
			resultat.append("Echec de l'inscription: Sans authentification ~~");
			return this.resultat.toString();
		}
		
		
		personneDao.insererPersonne(personne);
		
		resultat.append("Succes de l'inscriptionx");
		
		return this.resultat.toString();
	
	}
}
