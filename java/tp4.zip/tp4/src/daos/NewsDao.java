package daos;

import java.util.List;

import beans.NewsBean;
import beans.PersonneBean;

public interface NewsDao {
	void insererNews(NewsBean news);
	List<String> lireNews();
}
