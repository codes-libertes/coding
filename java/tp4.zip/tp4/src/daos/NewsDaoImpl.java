package daos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.NewsBean;

public class NewsDaoImpl implements NewsDao {

	@Override
	public void insererNews(NewsBean news) {
		// TODO Auto-generated method stub
		try {
			DaoDB.getInstance().createNews(news);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<String> lireNews() {
		// TODO Auto-generated method stub
		List<String> comments = new ArrayList<String>();
		try {
			comments = DaoDB.getInstance().lireNews();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return comments;
	}

}
