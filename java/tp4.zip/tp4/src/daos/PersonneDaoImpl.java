package daos;

import java.sql.SQLException;

import beans.PersonneBean;

public class PersonneDaoImpl implements PersonneDao {
	
	public PersonneDaoImpl(){
		
	}

	
	public void insererPersonne(PersonneBean personne){
		try {
			DaoDB.getInstance().createPersonne(personne);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Override
	public boolean verifierExistanceSelonLogin(PersonneBean personne) {
		// TODO Auto-generated method stub
		boolean rs = true;
		
		
		try {
			rs = DaoDB.getInstance().verifierExistanceSelonLogin(personne);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return rs;
	}


	@Override
	public boolean verifierExistanceSelonPassword(PersonneBean personne) {
		// TODO Auto-generated method stub
		boolean rs = true;
		
		
		try {
			rs = DaoDB.getInstance().verifierExistanceSelonPassword(personne);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return rs;
	}

}
