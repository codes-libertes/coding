package servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import singleton.LoginSingleton;

/**
 * Servlet implementation class HistoriseServlet
 */
@WebServlet("/HistoriseServlet")
public class HistoriseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HistoriseServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<String> historiques = LoginSingleton.getInstance().getLogin();
		
		request.setAttribute("historiques", historiques);
		
		request.getRequestDispatcher("/loginForm.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String[] location = request.getParameterValues("location");
		String lgn = request.getParameter("lgn");
		String pwd = request.getParameter("pwd");
		
		List<String> locs = new ArrayList<String>();
		
		for(int i = 0 ; i < location.length; i++) {
			locs.add(location[i]);
		}
		LoginSingleton.getInstance().setLogin(lgn,pwd,locs);
		request.setAttribute("lgn", lgn);
		request.getRequestDispatcher("/loginForm.jsp").forward(request, response);
	}

}
