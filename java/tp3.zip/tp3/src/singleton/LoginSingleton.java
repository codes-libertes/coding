package singleton;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LoginSingleton {
	private LoginSingleton(){
		
	}

	private static LoginSingleton INSTANCE = null; 
	
	public static LoginSingleton getInstance(){
		
		if( null == INSTANCE ){
			INSTANCE = new LoginSingleton();
		}
		
		return  INSTANCE;
		
	}
	
	public void setLogin(String lgn, String pwd, List<String> locations) throws IOException{
		
		StringBuilder locs = new StringBuilder();
		for(String loc : locations) {
			locs.append(loc);
			locs.append(" ");
		}
		
		Date date = new Date();
		
		SimpleDateFormat sdt = new SimpleDateFormat("EEE, dd MMM yyyy hh:mm:ss");

		BufferedWriter bw = new BufferedWriter(new FileWriter("/home/2017DRTEM1/e21700896/workspace/tp3/WebContent/login.txt",true));	
		
		bw.append(lgn);
		bw.append("-");
		bw.append(pwd);
		bw.append(" / ");
		bw.append(locs.toString());
		bw.append("\r\n");
		bw.close();
	}
	
	public List<String> getLogin() throws FileNotFoundException{
		List<String> historiques = new ArrayList<String>();
		
		/*Lire timezone.txt line par line*/
		BufferedReader br =  new BufferedReader(new FileReader("/home/2017DRTEM1/e21700896/workspace/tp3/WebContent/login.txt"));
		
		String line;
		try {
			while( null != (line = br.readLine())){
				historiques.add(line);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return historiques;
	}
	

	
}
