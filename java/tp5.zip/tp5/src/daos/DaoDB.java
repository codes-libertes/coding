package daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import beans.NewsBean;
import beans.PersonneBean;

public class DaoDB {
	private String url;
	private String user;
	private String password;
	
	private DaoDB(){
		
	}

	private static DaoDB INSTANCE = null; 
	
	public static DaoDB getInstance(){
		
		if( null == INSTANCE ){
			INSTANCE = new DaoDB();
		}
		
		return  INSTANCE;
	}
	
	public void createPersonne(PersonneBean personne) throws SQLException, ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/elec","elec", "elec");
        Statement stmt = conn.createStatement();
 
        StringBuilder strQuery = new StringBuilder();
        strQuery.append("INSERT INTO `personne`(`nom`, `prenom`, `login`, `password`,`site`) VALUES (");
        strQuery.append("'"+personne.getNom()+"','");
        strQuery.append(personne.getPrenom()+"','");
        strQuery.append(personne.getLogin()+"','");
        strQuery.append(personne.getPassword()+"','");
        strQuery.append(personne.getSite()+"'");
        strQuery.append(")\n");
        
        stmt.executeUpdate(strQuery.toString());
        conn.close();
	}
	
	public void createNews(NewsBean news) throws SQLException, ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/elec","elec", "elec");
        Statement stmt = conn.createStatement();
 
        StringBuilder strQuery = new StringBuilder();
        strQuery.append("INSERT INTO `news`(`comment`) VALUES (");
        strQuery.append("'"+news.getComment()+"')\n");
        
        stmt.executeUpdate(strQuery.toString());
        conn.close();
	}
	
	public List<String> lireNews() throws SQLException, ClassNotFoundException{
		
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/elec","elec", "elec");
        Statement stmt = conn.createStatement();
 
        StringBuilder strQuery = new StringBuilder();
        strQuery.append("SELECT * FROM news");
        ResultSet rs = stmt.executeQuery(strQuery.toString());
        
        List<String> comments = new ArrayList<String>();
        
        while(rs.next()){
        	comments.add(rs.getString(2));
        }
        
        conn.close();
        
        return comments;
	}
	
	public void updatePersonne(){
		
	}
	
	public boolean verifierExistanceSelonLogin(PersonneBean personne) throws ClassNotFoundException, SQLException{
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/elec","elec", "elec");
        Statement stmt = conn.createStatement();
        
        StringBuilder strQuery = new StringBuilder();
        strQuery.append("SELECT * FROM personne WHERE personne.login='");
        strQuery.append(personne.getLogin());
        strQuery.append("'\n");
    
        ResultSet rs = stmt.executeQuery(strQuery.toString());
        
        int compterLogin = 0 ;
        
        while(rs.next()){
        	compterLogin++;
        }
        
        System.out.println(compterLogin);
        if( compterLogin > 0){
        	conn.close();
        	return true;
        }
        
        conn.close();
		return false;
	}
	
	public boolean verifierExistanceSelonPassword(PersonneBean personne) throws ClassNotFoundException, SQLException{
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/elec","elec", "elec");
        Statement stmt = conn.createStatement();
        
        StringBuilder strQuery = new StringBuilder();
        strQuery.append("SELECT * FROM personne WHERE personne.password='");
        strQuery.append(personne.getPassword());
        strQuery.append("'\n");
    
        ResultSet rs = stmt.executeQuery(strQuery.toString());
        
        int compterPassword = 0 ;
        
        while(rs.next()){
        	compterPassword++;
        }
        
        if( compterPassword > 0){
        	conn.close();
        	return true;
        }
        
        conn.close();
		return false;
	}
}
