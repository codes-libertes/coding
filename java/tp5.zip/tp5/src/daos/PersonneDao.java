package daos;

import java.sql.SQLException;

import beans.PersonneBean;

public interface PersonneDao {

	void insererPersonne(PersonneBean personne);
	boolean verifierExistanceSelonLogin(PersonneBean personne);
	boolean verifierExistanceSelonPassword(PersonneBean personne);
}
