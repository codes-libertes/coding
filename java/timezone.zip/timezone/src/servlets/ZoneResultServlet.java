package servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.TimeLocBean;
import singleton.TimeLocBank;

/**
 * Servlet implementation class ZoneResultServlet
 */
@WebServlet("/ZoneResultServlet")
public class ZoneResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ZoneResultServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String[] location = request.getParameterValues("location");
		
		List<String> zones = new ArrayList<String>();
		
		for(int i = 0 ; i < location.length; i++) {
			zones.add(location[i]);
		}

		List<TimeLocBean> beans = TimeLocBank.getInstance().getTimeLocs(zones);
		request.setAttribute("beans", beans);
		request.getRequestDispatcher("/TimeZoneResult.jsp").forward(request, response);
		
	}

}
