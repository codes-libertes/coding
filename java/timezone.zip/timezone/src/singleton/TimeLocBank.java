package singleton;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import beans.TimeLocBean;

public class TimeLocBank {
	private TimeLocBank(){
		
	}

	private static TimeLocBank INSTANCE = null; 
	
	public static TimeLocBank getInstance(){
		
		if( null == INSTANCE ){
			INSTANCE = new TimeLocBank();
		}
		
		return  INSTANCE;
		
	}
	
	
	public List<String> getZones() throws FileNotFoundException{
		
		List<String> zones = new ArrayList<String>();
		
		/*Lire timezone.txt line par line*/
		BufferedReader br = new BufferedReader(new FileReader("/home/2017DRTEM1/e21700896/workspace/timezone/WebContent/timezone.txt"));
		String line;
		try {
			while( null != (line = br.readLine())){
				zones.add(line);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return zones;
	}
	
	private void loadZones(){
		
	}

	private String calculTime(String zone){
		StringBuilder time = new StringBuilder();
		
		String[] semaine = {"Dimanche","Lundi", "Mardi", "Mercredi", "Jeudi","Vendredi","Samedi"};
		
		Calendar calendar = Calendar.getInstance();

		calendar.setTimeZone(TimeZone.getTimeZone(zone));
		
		int year       = calendar.get(Calendar.YEAR);
		int month      = calendar.get(Calendar.MONTH);
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH); 
		
		int dayOfWeek  = calendar.get(Calendar.DAY_OF_WEEK);

		int hour       = calendar.get(Calendar.HOUR_OF_DAY); 
		int minute     = calendar.get(Calendar.MINUTE);
		int second     = calendar.get(Calendar.SECOND);
		
		time.append(year).append(":").append((month +1)).append(":").append(dayOfMonth).append("  ").append(semaine[dayOfWeek-1]).append("   ").append(hour).append(":").append(minute).append(":").append(second);
		
		return time.toString();
	}

	public List<TimeLocBean> getTimeLocs(List<String> zones) throws FileNotFoundException{
		
		List<TimeLocBean> tlb = new ArrayList<TimeLocBean>();
		
		for(String zone : zones) {
			TimeLocBean bean = new TimeLocBean();
			bean.setZone(zone);
			bean.setTime(calculTime(zone));
			tlb.add(bean);
		}
		
		return tlb;
	}
}
